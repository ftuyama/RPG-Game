#include "Ship.h"

Ship::Ship(){

}

int Ship::GetLives(){

    return lives;

}

void Ship::SetLives( int newValue){

    lives = newValue;

}

